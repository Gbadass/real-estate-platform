import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css"
import Section2 from "./component/Section2";
import Property from "./component/Property";
import Productdetails from "./component/Productdetails";



function App(){
  return(
    <div>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Section2/>}/>
        <Route path="/property" element={<Property/>}/>
        <Route path="/productdetails" element={<Productdetails/>}/>
      </Routes>
      </BrowserRouter>



    </div>
  )
}


export default App;